<?php
/*
 * Author        :   DHARSHAN
 * Date          :   27-12-2018
 * Modified      :   
 * Modified By   :   
 * Description   :   user interact logout 
 */
//echo "allow";die();

       // session_unset();
        session_destroy(); 
?>
<script>
  location.replace("<?php echo SITE_URL; ?>")
</script>
